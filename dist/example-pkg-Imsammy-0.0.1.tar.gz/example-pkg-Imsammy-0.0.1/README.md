# well_structured_repo
This is just a demo repo, a template loaded with most of the best repo structure practices
